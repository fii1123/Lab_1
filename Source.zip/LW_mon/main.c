#include <stdio.h>
#include <stdlib.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <mqueue.h>

// дешифорвка. возвращает размер пакета
unsigned short Deshif(const unsigned int *buff)
{
    char ip_from[16], ip_to[16], protocol;
    unsigned short port_f, port_t, total_len, udp_len;

    // ip
    inet_ntop(AF_INET, &buff[0], ip_from, 16);
    inet_ntop(AF_INET, &buff[1], ip_to, 16);

    // port
    port_f = (buff[2] & 0xFFFF0000) >> 16;
    port_t = buff[2] & 0xFFFF;

    // протокол, размер (полный и udp)
    protocol = (buff[3] & 0xFF0000) >> 16;
    total_len = buff[3] & 0xFFFF;
    udp_len = buff[4];

    printf("from[%s:%i]\tto[%s:%i]\n", ip_from, port_f, ip_to, port_t);
    printf("[protocol]: %i\t[len]: %i\t[udp len]:%i\n",
           protocol, total_len, udp_len);
    return total_len;
}

mqd_t Mq_open()
{
    struct mq_attr attr = {
        .mq_flags = 0,
        .mq_curmsgs = 0,
        .mq_maxmsg = 1000,
        .mq_msgsize = 20
    };
    mqd_t mq_id = mq_open("/LW", O_CREAT | O_RDWR,
                          S_IRUSR | S_IWUSR, &attr);
    if (mq_id == -1) {
        perror("mq error!");
        exit(EXIT_FAILURE);
    }
    return mq_id;
}

int main(int argc, char **argv)
{
    char buff[20] = {0};
    unsigned int total_size = 0;

    mqd_t mq_id = Mq_open();

    // Запрос статистики
    if(mq_send(mq_id, "1", 20, 1) == -1){
        perror("Send error!");
        exit(EXIT_FAILURE);
    }
    // полчучение числа пакетов
    mq_receive(mq_id, buff, 20, NULL);
    unsigned short i, pockets_count = atoi(buff);

    for (i = 0; i < pockets_count; i++){
        mq_receive(mq_id, buff, 20, NULL);
        total_size += Deshif((unsigned int *)buff);
    }
    puts("==========================");
    printf("Pockets catch: %i\n", pockets_count);
    printf("Total size: %i\n", total_size);

    mq_close(mq_id);

    return 0;
}
