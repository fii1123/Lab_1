#!/bin/bash

mkdir tmp
cmake -S . -B ./tmp/
cd tmp/
make
mv tmp/LW1 .