#include <stdio.h>
#include <stdlib.h>
#include <string.h>     //memcpy

// Библиотеки сети
#include <sys/socket.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// Для работы с пакетами
#include <features.h>           // Для версии glibc
#if __GLIBC__ >= 2 && __GLIBC_MINOR >= 1
#include <netpacket/packet.h>
#include <net/ethernet.h>       // Протоколы L2
#else
#include <asm/types.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>     // Протоколы L2
#endif

// Потоки
#include <pthread.h>

/* Для отладки
 * DEBUG 1 - для вывода основной информации
 * DEBUG 2 - для вывода всего пакета
 */
#define DEBUG 1
// argv[1] / "lo"/ "enp2s0f1"
#define NET_DEV "lo"

// структура аргументов для потоков
struct Argum{
    int sock;
    size_t bite_count;
    char buff[4096];
    unsigned short buff_len;
};

// Функция определяет точку считывания данных
char get_data_index(const char *buff){
    char ip_hed_len, data_point = 62; // 62 псевдо udp

    memcpy(&ip_hed_len, buff + ETH_HLEN, 1);
    // 4-7 биты содержат размер заголовка
    ip_hed_len = ip_hed_len & 0xF;

    if (ip_hed_len > 5){
        return data_point + 4;
    }
    return data_point;
}

// Функция формирования статистики
void Statist(const char *buff, unsigned long *bite_count){

    char ip_from[16], ip_to[16];
    unsigned int ip_num;
    unsigned short port_f, port_t;

    // ip адреса

    memcpy(&ip_num, buff + 26, 4);
    inet_ntop(AF_INET, &ip_num, ip_from, 16);

    memcpy(&ip_num, buff + 30, 4);
    inet_ntop(AF_INET, &ip_num, ip_to, 16);

    //порты
    char data_index = get_data_index(buff);

    memcpy(&port_f, buff + data_index, 2);
    memcpy(&port_t, buff + data_index + 2, 2);
    port_f = ntohs(port_f);
    port_t = ntohs(port_t);

#if DEBUG == 2

    printf("%s: {\n",ip_from);
    unsigned long i;
    for(i=0; i < (unsigned long) *(bite_count);i++){
        if (i % 4 == 0){
            printf("\n");
        }
        printf("%0i\t",buff[i+ETH_HLEN]);
    }
    printf("}\n");

#else
    printf("from[%s]:%i\tto[%s]:%i  \tsize:%lib\n", ip_from,
           port_f, ip_to, port_t, *bite_count);
#endif

}

void *Listening_thread (void *argum)
{
    struct Argum *a = argum;

    puts("Listening...");
    while (1) {

        a->bite_count = recv(a->sock, a->buff, a->buff_len, 0);
    }
}

void *Secondary_tread (void *argum)
{
    struct Argum *a = argum;

    while (1) {
        if(a->bite_count > 0){
            Statist(a->buff,&(a->bite_count));
            a->bite_count=0;
        }
    }

}

int main (int argc, char **argv)
{
#if DEBUG == 0
    if (argc < 2) {
        perror("Need more arg!");
        exit(EXIT_FAILURE);
    }
#endif

    int raw_socket = socket(AF_PACKET, SOCK_RAW, IPPROTO_UDP);
    if (raw_socket == -1) {
        perror("Socket error!");
        exit(EXIT_FAILURE);
    }

    // определение индекса сетевого интерфейса
    struct ifreq if_req = {
        .ifr_name = NET_DEV
    };
    if (ioctl(raw_socket, SIOCGIFINDEX, &if_req, sizeof(if_req)) == -1) {
        perror("ioctl error!");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_ll sa = {
        .sll_family = AF_PACKET,
        .sll_protocol = htons(ETH_P_ALL),
        .sll_ifindex = if_req.ifr_ifindex
    };

    if (bind(raw_socket, (struct sockaddr *) &sa, sizeof(sa)) == -1) {
        perror("Bind error!");
        exit(EXIT_FAILURE);
    }

    // подготовка потоков
    pthread_t List_thread_id, Secd_thread_id;
    pthread_attr_t thr_attr;

    pthread_attr_init(&thr_attr);       // по умолчанию

    // аргументы для передачи в поток
    struct Argum a = {
        .sock = raw_socket,
        .buff_len = sizeof(a.buff)
    };

    // процессы
    pthread_create(&List_thread_id, &thr_attr, Listening_thread, &a);

    pthread_create(&Secd_thread_id, &thr_attr, Secondary_tread, &a);

    // q - выход
    while(getchar() != 'q'){}


    return 0;
}

