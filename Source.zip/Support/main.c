#include <stdio.h>
#include <stdlib.h>

//сеть
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char* argv[])
{
    int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
    u_int16_t Port;

    puts("На какой порт отправлять?");
    scanf("%i", (int *) &Port);

    struct sockaddr_in sa;
    inet_aton("127.0.0.1", &sa.sin_addr);       // 192.168.0.4
    sa.sin_family = AF_INET;
    sa.sin_port = htons(Port);
    socklen_t sa_size = sizeof(sa);

    //bind(udp_socket,(struct sockaddr *)&sa,sa_size);

    char buff[2048] = {0};
    int len = 2048;

    printf("message for [127.0.0.1:%i]\n", Port);
    while (buff[0] != 'q') {
        len = scanf("%s", buff);
        sendto(udp_socket, buff, len, 0, (struct sockaddr *) &sa, sa_size);
    }
    return 0;
}
